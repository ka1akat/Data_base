create function calculate_discount(original_price numeric, discount_percent numeric) returns numeric
    language plpgsql
as
$$
BEGIN
    RETURN original_price - (original_price * discount_percent / 100);
END;
$$;

alter function calculate_discount(numeric, numeric) owner to karakatzaslan;

