create view employee_details(emp_name, salary, dept_name, location, salary_grade) as
SELECT e.emp_name,
       e.salary,
       d.dept_name,
       d.location,
       CASE
           WHEN e.salary > 60000::numeric THEN 'High'::text
           WHEN e.salary > 50000::numeric THEN 'Medium'::text
           ELSE 'Standard'::text
           END AS salary_grade
FROM employees e
         JOIN departments d ON e.dept_id = d.dept_id;

alter table employee_details
    owner to karakatzaslan;

