create view dept_statistics(dept_name, employee_count, avg_salary, max_salary, min_salary) as
SELECT d.dept_name,
       count(e.emp_id) AS employee_count,
       avg(e.salary)   AS avg_salary,
       max(e.salary)   AS max_salary,
       min(e.salary)   AS min_salary
FROM departments d
         LEFT JOIN employees e ON d.dept_id = e.dept_id
GROUP BY d.dept_name;

alter table dept_statistics
    owner to karakatzaslan;

